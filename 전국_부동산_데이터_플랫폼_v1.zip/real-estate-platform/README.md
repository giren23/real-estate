# 전국 부동산 데이터 플랫폼 v1

전국 아파트·모든 전용면적의 매매 실거래를 수집해 실거래가, 전용면적 환산 평당가, 거래량, 단지별 가격변동을 분석하고 GitHub Pages에서 모바일로 조회하는 프로젝트입니다.

## 현재 구현

- 국토부 아파트 매매 실거래 API 수집
- 모든 평형 지원
- 취소·해제 거래 제외
- 거래금액·㎡당가·전용면적 환산 평당가 계산
- 단지별 최고·최저·중위가·가격범위
- 지역별 월간 거래량·중위가격·평당가 증감
- 인구·세대·전입·전출 CSV 결합
- 지역·단지·면적 검색
- 거래일-금액 및 거래일-평당가 선차트
- GitHub Actions 자동 갱신 및 Pages 배포

## 모바일 Codespaces에서 설치

터미널에서 ZIP 파일이 있는 경로를 확인한 뒤 저장소 루트에서 압축을 풉니다.

```bash
unzip 전국_부동산_데이터_플랫폼_v1.zip -d /tmp/realestate
cp -a /tmp/realestate/. /workspaces/real-estate/
git add .
git commit -m "Install nationwide real-estate platform"
git push
```

ZIP을 휴대폰에만 내려받았다면 Codespaces 탐색기 상단 `...` → `Upload...`로 ZIP 한 개만 올린 후 위 명령을 실행합니다.

## GitHub 설정

1. 저장소 `Settings → Secrets and variables → Actions`
2. `New repository secret`
3. 이름: `MOLIT_SERVICE_KEY`
4. 값: 공공데이터포털 서비스키
5. `Actions → Bootstrap real-estate data → Run workflow`
6. 초기 수집은 1개월부터 시작
7. `Settings → Pages → Source: GitHub Actions`

## 전국 운영 주의

현재 `config/regions.csv`는 대표 지역 시드입니다. 전국 전체 시군구 코드는 공식 법정동 코드 자료로 확장해야 합니다. 전국 과거 데이터를 한 번에 전부 수집하면 API 일일 호출량과 Git 저장공간을 초과할 수 있으므로 지역·기간을 나눠 수집하는 것을 권장합니다.

특정 지역만 수집:

```bash
PYTHONPATH=src python -m realestate.cli.main collect --codes 41135,11680 --start 202501 --end 202612
PYTHONPATH=src python -m realestate.cli.main publish
```

## 평당가 정의

본 프로젝트의 평당가는 `거래금액 ÷ (전용면적㎡ ÷ 3.305785)`입니다. 공급면적 기준 광고 평당가와 다를 수 있습니다.

## 15단계 설계

`docs/15_STAGE_PLAN.md`를 확인하세요.
