from __future__ import annotations
import time, xml.etree.ElementTree as ET
from pathlib import Path
import pandas as pd
from realestate.core.http import get_text
from realestate.core.settings import Settings

ALIASES = {
    "apt": ["aptNm", "아파트"], "dong": ["umdNm", "법정동"], "jibun": ["jibun", "지번"],
    "amount": ["dealAmount", "거래금액"], "area": ["excluUseAr", "전용면적"],
    "floor": ["floor", "층"], "year": ["dealYear", "년"], "month": ["dealMonth", "월"],
    "day": ["dealDay", "일"], "build": ["buildYear", "건축년도"],
    "deal_type": ["dealingGbn", "거래유형"], "cancel": ["cdealDay", "해제사유발생일"],
    "registration": ["rgstDate", "등기일자"], "apt_dong": ["aptDong", "동"]
}

def pick(row: dict, names: list[str]) -> str:
    for n in names:
        if n in row and row[n] is not None:
            return str(row[n]).strip()
    return ""

def num(v: str) -> float:
    try: return float(str(v).replace(",", "").strip())
    except (TypeError, ValueError): return 0.0

def parse_trade_xml(xml_text: str, lawd_cd: str, region_name: str, deal_ym: str) -> pd.DataFrame:
    root = ET.fromstring(xml_text)
    code, msg = root.findtext(".//resultCode"), root.findtext(".//resultMsg")
    if code and code not in {"00", "000"}:
        raise RuntimeError(f"국토부 API 오류 {code}: {msg}")
    rows = []
    for item in root.findall(".//item"):
        raw = {c.tag: (c.text or "").strip() for c in item}
        y, m, d = int(num(pick(raw, ALIASES["year"]))), int(num(pick(raw, ALIASES["month"]))), int(num(pick(raw, ALIASES["day"])))
        amount, area = int(num(pick(raw, ALIASES["amount"]))), num(pick(raw, ALIASES["area"]))
        if not (y and m and d and amount and area):
            continue
        pyeong = area / 3.305785
        rows.append({
            "lawd_cd": lawd_cd, "region_name": region_name, "deal_ym": deal_ym,
            "trade_date": f"{y:04d}-{m:02d}-{d:02d}", "apt_name": pick(raw, ALIASES["apt"]),
            "dong": pick(raw, ALIASES["dong"]), "jibun": pick(raw, ALIASES["jibun"]),
            "apt_dong": pick(raw, ALIASES["apt_dong"]), "area_m2": round(area, 2),
            "area_pyeong": round(pyeong, 2), "floor": int(num(pick(raw, ALIASES["floor"]))),
            "build_year": int(num(pick(raw, ALIASES["build"]))), "price_manwon": amount,
            "price_eok": round(amount / 10000, 4), "price_per_m2_manwon": round(amount / area, 2),
            "price_per_pyeong_manwon": round(amount / pyeong, 2),
            "deal_type": pick(raw, ALIASES["deal_type"]), "registration_date": pick(raw, ALIASES["registration"]),
            "cancelled": bool(pick(raw, ALIASES["cancel"]))
        })
    return pd.DataFrame(rows)

def fetch_trade_month(settings: Settings, lawd_cd: str, region_name: str, deal_ym: str) -> pd.DataFrame:
    if not settings.service_key:
        raise RuntimeError("MOLIT_SERVICE_KEY가 필요합니다.")
    text = get_text(settings.trade_endpoint, {
        "serviceKey": settings.service_key, "LAWD_CD": lawd_cd, "DEAL_YMD": deal_ym,
        "pageNo": 1, "numOfRows": 9999
    })
    return parse_trade_xml(text, lawd_cd, region_name, deal_ym)

def collect_trades(settings: Settings, regions: pd.DataFrame, months: list[str], output_dir: Path) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    for _, region in regions.iterrows():
        code, name = str(region["lawd_cd"]).zfill(5), str(region["region_name"])
        for ym in months:
            target = output_dir / f"{code}_{ym}.parquet"
            try:
                df = fetch_trade_month(settings, code, name, ym)
                if not df.empty: df = df[~df["cancelled"]].copy()
                df.to_parquet(target, index=False)
                print(f"[OK] {name} {ym}: {len(df):,}건")
            except Exception as exc:
                print(f"[ERROR] {name} {ym}: {exc}")
            time.sleep(settings.request_delay_seconds)
