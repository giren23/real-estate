from __future__ import annotations
import json, os
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import unquote

ROOT = Path(__file__).resolve().parents[3]

@dataclass(frozen=True)
class Settings:
    service_key: str
    trade_endpoint: str
    default_history_months: int
    max_months_per_run: int
    request_delay_seconds: float


def load_settings() -> Settings:
    path = Path(os.getenv("REALESTATE_CONFIG", ROOT / "config/settings.json"))
    if not path.exists():
        path = ROOT / "config/settings.example.json"
    data = json.loads(path.read_text(encoding="utf-8"))
    key = os.getenv("MOLIT_SERVICE_KEY", "").strip()
    if "%" in key:
        key = unquote(key)
    return Settings(
        service_key=key,
        trade_endpoint=data["trade_endpoint"],
        default_history_months=int(data.get("default_history_months", 12)),
        max_months_per_run=int(data.get("max_months_per_run", 24)),
        request_delay_seconds=float(data.get("request_delay_seconds", 0.15)),
    )
