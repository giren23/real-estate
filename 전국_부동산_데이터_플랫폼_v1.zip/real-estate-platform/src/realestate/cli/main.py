from __future__ import annotations
import argparse
from pathlib import Path
import pandas as pd
from realestate.core.dates import month_range, recent_month_range
from realestate.core.settings import ROOT, load_settings
from realestate.collectors.trades import collect_trades
from realestate.analysis.publish import build_public_data

def main() -> None:
    parser = argparse.ArgumentParser(description="전국 부동산 데이터 플랫폼")
    sub = parser.add_subparsers(dest="command", required=True)
    c = sub.add_parser("collect")
    c.add_argument("--regions", default=str(ROOT / "config/regions.csv"))
    c.add_argument("--start"); c.add_argument("--end"); c.add_argument("--months", type=int, default=12)
    c.add_argument("--codes"); c.add_argument("--output", default=str(ROOT / "data/raw/trades"))
    sub.add_parser("publish")
    args = parser.parse_args(); settings = load_settings()
    if args.command == "collect":
        regions = pd.read_csv(args.regions, dtype={"lawd_cd": str})
        if args.codes:
            codes = {x.strip() for x in args.codes.split(",")}; regions = regions[regions["lawd_cd"].isin(codes)]
        if args.start and args.end: months = month_range(args.start, args.end)
        else:
            s,e = recent_month_range(args.months); months = month_range(s,e)
        if len(months) > settings.max_months_per_run: raise SystemExit(f"한 번에 최대 {settings.max_months_per_run}개월입니다.")
        collect_trades(settings, regions, months, Path(args.output)); return
    build_public_data(ROOT); print("data/public 생성 완료")

if __name__ == "__main__": main()
