from __future__ import annotations
import json
from pathlib import Path
import pandas as pd
from realestate.analysis.metrics import apartment_metrics, monthly_trade_metrics, regional_metrics
from realestate.collectors.population import load_population_csv

def load_parquets(folder: Path) -> pd.DataFrame:
    paths = sorted(folder.glob("*.parquet"))
    frames = [pd.read_parquet(p) for p in paths]
    return pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()

def records(df: pd.DataFrame) -> list[dict]:
    if df.empty: return []
    return df.where(pd.notna(df), None).to_dict(orient="records")

def build_public_data(root: Path) -> None:
    trades = load_parquets(root / "data/raw/trades")
    population = load_population_csv(root / "data/raw/population/population.csv")
    out = root / "data/public"; out.mkdir(parents=True, exist_ok=True)
    if trades.empty:
        (out / "meta.json").write_text(json.dumps({"status":"empty","message":"아직 실거래 데이터가 없습니다."}, ensure_ascii=False, indent=2), encoding="utf-8")
        return
    trades = trades.sort_values("trade_date")
    payloads = {
        "meta.json": {"status":"ok","trade_count":int(len(trades)),"region_count":int(trades["lawd_cd"].nunique()),"apartment_count":int(trades[["lawd_cd","dong","apt_name"]].drop_duplicates().shape[0]),"first_date":str(trades["trade_date"].min()),"latest_date":str(trades["trade_date"].max())},
        "latest_trades.json": records(trades.sort_values("trade_date", ascending=False).head(5000)),
        "apartments.json": records(apartment_metrics(trades).sort_values("latest_trade_date", ascending=False)),
        "monthly.json": records(monthly_trade_metrics(trades)),
        "regional.json": records(regional_metrics(trades, population)),
        "regions.json": records(trades[["lawd_cd","region_name"]].drop_duplicates().sort_values("region_name"))
    }
    for name, payload in payloads.items():
        (out / name).write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
