from __future__ import annotations
import pandas as pd

def add_size_band(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out["size_band"] = pd.cut(out["area_m2"], [0,40,60,85,102,135,float("inf")], labels=["40㎡ 미만","40~59㎡","60~84㎡","85~101㎡","102~134㎡","135㎡ 이상"], right=False)
    return out

def monthly_trade_metrics(trades: pd.DataFrame) -> pd.DataFrame:
    if trades.empty: return pd.DataFrame()
    df = add_size_band(trades)
    df["month"] = df["trade_date"].str[:7]
    return df.groupby(["lawd_cd","region_name","month","size_band"], observed=True).agg(
        trade_count=("price_eok","size"), median_price_eok=("price_eok","median"),
        average_price_eok=("price_eok","mean"), median_pyeong_price_manwon=("price_per_pyeong_manwon","median"),
        average_pyeong_price_manwon=("price_per_pyeong_manwon","mean")
    ).reset_index()

def apartment_metrics(trades: pd.DataFrame) -> pd.DataFrame:
    if trades.empty: return pd.DataFrame()
    df = trades.sort_values("trade_date").copy()
    keys = ["lawd_cd","region_name","dong","apt_name","area_m2"]
    out = df.groupby(keys, dropna=False).agg(
        trade_count=("price_eok","size"), first_trade_date=("trade_date","first"), first_price_eok=("price_eok","first"),
        latest_trade_date=("trade_date","last"), latest_price_eok=("price_eok","last"), min_price_eok=("price_eok","min"),
        max_price_eok=("price_eok","max"), median_price_eok=("price_eok","median"),
        median_pyeong_price_manwon=("price_per_pyeong_manwon","median")
    ).reset_index()
    out["range_eok"] = out["max_price_eok"] - out["min_price_eok"]
    out["first_to_latest_change_eok"] = out["latest_price_eok"] - out["first_price_eok"]
    out["first_to_latest_change_pct"] = out["first_to_latest_change_eok"] / out["first_price_eok"] * 100
    return out

def regional_metrics(trades: pd.DataFrame, population: pd.DataFrame) -> pd.DataFrame:
    if trades.empty: return pd.DataFrame()
    df = trades.copy(); df["month"] = df["trade_date"].str[:7]
    out = df.groupby(["lawd_cd","region_name","month"]).agg(
        trade_count=("price_eok","size"), median_price_eok=("price_eok","median"),
        median_pyeong_price_manwon=("price_per_pyeong_manwon","median")
    ).reset_index()
    out["pyeong_price_change_pct"] = out.groupby("lawd_cd")["median_pyeong_price_manwon"].pct_change(fill_method=None) * 100
    if not population.empty:
        pop = population.rename(columns={"region_code":"lawd_cd"})
        out = out.merge(pop, on=["lawd_cd","month"], how="left")
    return out
