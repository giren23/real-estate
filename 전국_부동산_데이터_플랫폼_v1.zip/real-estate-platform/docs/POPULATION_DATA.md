# 인구·세대·가감동향 연결

`data/raw/population/population.csv` 파일을 다음 형식으로 저장합니다.

```csv
region_code,region_name,month,population,households,move_in,move_out
41135,경기도 성남시 분당구,2026-01,473000,199000,5200,5500
```

필수: region_code, region_name, month(YYYY-MM), population, households
선택: move_in, move_out

자동 계산: 인구 증감·증감률, 세대수 증감, 순이동(전입-전출).
